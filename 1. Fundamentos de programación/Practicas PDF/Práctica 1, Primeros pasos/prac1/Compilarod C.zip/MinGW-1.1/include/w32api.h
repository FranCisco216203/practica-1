#ifndef _W32API_H_
#define _W32API_H_

#define __W32API_VERSION 1.1
#define __W32API_MAJOR_VERSION 1
#define __W32API_MINOR_VERSION 1

#endif /* ndef _W32API_H_ */
